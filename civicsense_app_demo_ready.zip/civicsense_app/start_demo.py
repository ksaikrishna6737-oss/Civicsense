"""Start CivicSense so that this laptop AND phones on the same Wi-Fi can open it."""
import subprocess
import sys
from netinfo import lan_ip

PORT = 8501
ip = lan_ip()
print("=" * 60)
print(" CivicSense demo is starting")
print(f" On this laptop:         http://localhost:{PORT}")
print(f" On phones (same Wi-Fi): http://{ip}:{PORT}")
print(" Leave this window open while you demo. Press Ctrl+C to stop.")
print("=" * 60)
subprocess.run([sys.executable, "-m", "streamlit", "run", "app.py", "--server.address", "0.0.0.0", "--server.port", str(PORT)])
