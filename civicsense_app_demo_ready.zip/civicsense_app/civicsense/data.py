"""Step 0: fake-but-realistic complaint data, so we can build and test before real data exists.

Each generated complaint remembers its TRUE category and TRUE issue id. The model never sees
these; we only use them afterwards to check whether the model got things right.
"""
import random
from datetime import datetime, timedelta
import pandas as pd

# Approximate area centres (lat, lon) in Hyderabad -- enough for a realistic simulation
LOCATIONS = {"Banjara Hills": (17.4126, 78.4482), "Jubilee Hills": (17.4326, 78.4071),
             "Ameerpet": (17.4375, 78.4483), "Kukatpally": (17.4849, 78.4138),
             "Secunderabad": (17.4399, 78.4983), "Dilsukhnagar": (17.3688, 78.5247),
             "Madhapur": (17.4483, 78.3915), "Gachibowli": (17.4401, 78.3489)}
ROADS = ["Main Road", "Road No. 12", "Station Road", "Market Street", "Ring Road"]
LANDMARKS = ["the bus stop", "the school", "the park", "the hospital", "the temple", "the metro station"]

TEMPLATES = {
    "pothole": ["Large pothole on {road}", "Deep pothole near {landmark}",
                "Road full of potholes after rain", "Pothole causing traffic jam near {landmark}",
                "Big hole in the middle of {road}, bikes skidding",
                "Broken road surface near {landmark}, accident risk"],
    "garbage": ["Garbage not collected for {n} days", "Overflowing garbage bin near {landmark}",
                "Waste piled up on {road}", "Trash not cleared, bad smell",
                "Garbage dump on the roadside near {landmark}", "Dustbin overflowing, rubbish scattered"],
    "streetlight": ["Streetlight not working near {landmark}", "Street light pole damaged on {road}",
                    "Lights off on {road}, area dark and unsafe at night",
                    "Broken street lamp near {landmark}", "No light on the road since {n} days"],
    "water_leak": ["Water pipe leaking on {road}", "Water leakage near {landmark}, water wasted",
                   "Burst water main flooding {road}", "Drinking water pipeline broken near {landmark}",
                   "Continuous water leak from pipe for {n} days"],
    "sewage": ["Sewage water overflowing on {road}", "Drain blocked near {landmark}, dirty water on road",
               "Manhole overflow near {landmark}", "Sewage smell and open drain on {road}",
               "Dirty water from drainage entering homes near {landmark}"],
}
# Short, lazy complaints people really write
SHORT = {
    "pothole": ["pothole", "pothole on road!!", "road has big hole"],
    "garbage": ["garbage", "garbage not cleared", "dustbin full"],
    "streetlight": ["no light", "light not working", "street light off"],
    "water_leak": ["water leaking", "pipe leak", "water wasted"],
    "sewage": ["drain blocked", "sewage overflow", "dirty water on road"],
}


def _typo(text, rng):
    words = text.split()
    i = rng.randrange(len(words))
    w = words[i]
    if len(w) > 3:
        j = rng.randrange(1, len(w) - 1)
        words[i] = w[:j] + w[j + 1:]  # drop one letter
    return " ".join(words)


# Hard mode only: re-wordings with vocabulary the model never saw in training
PARA = {
    "pothole": ["road crater near the junction", "hole in the road, tyres getting damaged", "damaged tarmac", "road caved in"],
    "garbage": ["trash heap on the corner", "rubbish pile rotting", "waste dumped on the footpath", "bin not emptied for ages"],
    "streetlight": ["lamp post is dead", "road is dark, bulb gone", "light pole out of order", "no illumination on this lane"],
    "water_leak": ["pipe burst, water flowing everywhere", "tap line broken and gushing", "leaking main spilling water", "water pouring from underground pipe"],
    "sewage": ["gutter overflowing onto the road", "stinking filth flowing on the street", "manhole spilling over", "drain choked, filth on road"],
}


def _write_complaint(category, rng, hard=False, para=0.3, spot=None):
    if hard and rng.random() < para:
        text = rng.choice(PARA[category])
    elif rng.random() < 0.15:
        text = rng.choice(SHORT[category])
    else:
        text = rng.choice(TEMPLATES[category]).format(
            road=rng.choice(ROADS), landmark=rng.choice(LANDMARKS), n=rng.randint(2, 6))
    if hard and spot and rng.random() < 0.7:      # people usually name the place; the SAME issue keeps the same landmark
        text = f"{text} {rng.choice(['near', 'close to', 'opposite'])} {spot[1]}"
    if rng.random() < (0.35 if hard else 0.15):
        text = _typo(text, rng)
    return text


def generate(n=600, seed=0, dup_prob=0.3, now=datetime(2026, 10, 26), hard=False):
    """Make n complaints. About dup_prob of them are re-reports of an earlier issue."""
    rng = random.Random(seed)
    issues, rows = [], []
    jit = 0.0008 if hard else 0.0003     # GPS error: ~30 m normally, ~90 m in hard mode
    for _ in range(n):
        if issues and rng.random() < dup_prob:
            issue = rng.choice(issues[-40:])                     # someone re-reports a recent issue
            ts = min(issue["created_at"] + timedelta(hours=rng.randint(1, 24 * 5)), now)
            is_re = True
        else:
            area = rng.choice(list(LOCATIONS))
            clat, clon = LOCATIONS[area]
            issue = {"id": len(issues), "category": rng.choice(list(TEMPLATES)), "location": area,
                     "lat": clat + rng.uniform(-0.01, 0.01),   # a random spot within ~1 km of the centre
                     "lon": clon + rng.uniform(-0.01, 0.01),
                     "created_at": now - timedelta(days=30 * rng.random())}
            if hard:
                issue["spot"] = (rng.choice(ROADS), rng.choice(LANDMARKS))
            if hard and issues and rng.random() < 0.35:   # a DIFFERENT problem on the same stretch, 40-120 m away
                base = rng.choice(issues[-40:])
                issue.update(category=base["category"], location=base["location"],
                             lat=base["lat"] + rng.choice([-1, 1]) * rng.uniform(0.0004, 0.0008),
                             lon=base["lon"] + rng.choice([-1, 1]) * rng.uniform(0.0004, 0.0008),
                             created_at=min(base["created_at"] + timedelta(hours=rng.randint(1, 72)), now))
                issue["spot"] = (rng.choice(ROADS), rng.choice([l for l in LANDMARKS if l != base["spot"][1]]))
            issues.append(issue)
            ts = issue["created_at"]
            is_re = False
        # a re-report comes from the same spot, give or take ~30 m of GPS/phone error
        rows.append({"text": _write_complaint(issue["category"], rng, hard, 0.6 if (hard and is_re) else 0.3, issue.get("spot")), "location": issue["location"],
                     "lat": issue["lat"] + rng.uniform(-jit, jit),
                     "lon": issue["lon"] + rng.uniform(-jit, jit), "created_at": ts, "true_category": issue["category"], "true_issue_id": issue["id"]})
    df = pd.DataFrame(rows).sort_values("created_at").reset_index(drop=True)
    df.insert(0, "complaint_id", df.index)
    return df
