"""Glue: runs every complaint through categorize -> severity -> duplicate check -> priority."""
import pandas as pd
from .categorizer import Categorizer
from .severity import score_severity
from .duplicates import DuplicateDetector
from .priority import priority_score, explain


class CivicSensePipeline:
    def __init__(self, dup_threshold=0.0, window_days=7, radius_m=100, backend="tfidf_word",
                 char_ngrams=True, review_below=0.5):
        self.cat = Categorizer(char_ngrams)
        self.dup = DuplicateDetector(dup_threshold, window_days, radius_m, backend)
        self.review_below = review_below     # confidence under this -> flagged for a human to check

    def fit(self, texts, labels):
        self.cat.fit(texts, labels)
        self.dup.fit(texts)
        return self

    def run(self, df, now=None):
        """df needs: complaint_id, text, location, lat, lon, created_at. Returns (complaints, ranked_issues)."""
        df = df.sort_values("created_at")
        issues, by_id, rows = [], {}, []
        for r in df.itertuples():
            category, conf, keywords = self.cat.predict(r.text)
            sev, reasons = score_severity(r.text, category)
            m = self.dup.match(r.text, r.lat, r.lon, category, r.created_at, issues)
            if m:
                issue = by_id[m[0]]
                issue["texts"].append(r.text)
                issue["last_reported"] = r.created_at
                issue["n_reports"] += 1
                if sev > issue["severity"]:
                    issue["severity"], issue["severity_reasons"] = sev, reasons
            else:
                issue = {"id": len(issues), "category": category, "location": r.location, "lat": r.lat, "lon": r.lon, "texts": [r.text],
                         "first_reported": r.created_at, "last_reported": r.created_at, "n_reports": 1,
                         "severity": sev, "severity_reasons": reasons, "keywords": keywords}
                issues.append(issue)
                by_id[issue["id"]] = issue
            rows.append({"complaint_id": r.complaint_id, "predicted_category": category,
                         "confidence": round(conf, 3), "needs_review": conf < self.review_below,
                         "severity": sev, "issue_id": issue["id"]})

        now = now if now is not None else df["created_at"].max()
        out = []
        for i in issues:
            i["age_days"] = (now - i["first_reported"]).days
            score, parts = priority_score(i["severity"], i["n_reports"], i["age_days"])
            out.append({"issue_id": i["id"], "category": i["category"], "location": i["location"],
                        "lat": round(i["lat"], 5), "lon": round(i["lon"], 5),
                        "first_reported": i["first_reported"],
                        "reports": i["n_reports"], "severity": i["severity"], "age_days": i["age_days"],
                        "priority": score, "why": explain(i, score, parts)})
        ranked = pd.DataFrame(out).sort_values("priority", ascending=False).reset_index(drop=True)
        ranked.insert(0, "rank", ranked.index + 1)
        return pd.DataFrame(rows), ranked
