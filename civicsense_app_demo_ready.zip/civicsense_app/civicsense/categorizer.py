"""Step 1: decide what KIND of complaint this is (pothole, garbage, ...) -- and say which words decided it.

Option added in v2: char_ngrams=True adds character 2-5-grams, so a misspelling like 'pothhole'
still shares pieces with 'pothole'. Low confidence is flagged by the pipeline (needs_review).
"""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import FeatureUnion


class Categorizer:
    def __init__(self, char_ngrams=False):
        word = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)
        self.char_ngrams = char_ngrams
        self.vec = FeatureUnion([("w", word), ("c", TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), sublinear_tf=True))]) if char_ngrams else word
        self.clf = LogisticRegression(max_iter=1000)

    def fit(self, texts, labels):
        self.clf.fit(self.vec.fit_transform(texts), labels)
        return self

    def predict(self, text):
        """Returns (category, confidence 0-1, [top reason words])."""
        x = self.vec.transform([text])
        probs = self.clf.predict_proba(x)[0]
        k = int(probs.argmax())
        label = self.clf.classes_[k]
        contrib = x.multiply(self.clf.coef_[k]).tocoo()
        names = self.vec.get_feature_names_out()
        ranked = sorted(zip(contrib.col, contrib.data), key=lambda p: -p[1])
        words = []
        for c, v in ranked:
            name = str(names[c])
            if self.char_ngrams:
                if not name.startswith("w__"):      # explain with whole words only
                    continue
                name = name[3:]
            if v > 0 and len(words) < 3:
                words.append(name)
        return label, float(probs[k]), words
