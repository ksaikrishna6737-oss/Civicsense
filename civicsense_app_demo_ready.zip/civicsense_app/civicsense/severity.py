"""Step 2: how SERIOUS is it (1-5)? Pure rules, so every point can be explained.

There is no labelled severity data yet, so a model would just be guessing. Rules are honest here:
a base score per category, plus bonuses for danger signals found in the text.
"""
import re

BASE = {"pothole": 2, "garbage": 2, "streetlight": 2, "water_leak": 2, "sewage": 3}

# (words that trigger it, points added, reason shown to the user)
BOOSTS = [
    (("accident", "skid", "injur"), 2, "accident/injury risk mentioned"),
    (("unsafe", "dark", "night"), 1, "safety concern after dark"),
    (("hospital", "school"), 1, "near a hospital or school"),
    (("flood", "burst", "entering homes", "overflow"), 1, "active flooding/overflow"),
]


def score_severity(text, category):
    t = text.lower()
    score, reasons = BASE.get(category, 2), [f"base for {category}"]
    for words, points, why in BOOSTS:
        if any(w in t for w in words):
            score += points
            reasons.append(why)
    m = re.search(r"(\d+)\s*days", t)
    if m and int(m.group(1)) >= 3:
        score += 1
        reasons.append(f"unresolved for {m.group(1)} days")
    return min(score, 5), reasons
