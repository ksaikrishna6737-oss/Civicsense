"""Step 4: combine everything into ONE priority score (0-100) and a sentence explaining it.

priority = 100 * ( w_sev * severity/5  +  w_rep * min(reports,10)/10  +  w_age * min(age_days,14)/14 )

The weights are a DESIGN CHOICE, not something learned -- change them in WEIGHTS and re-rank.
"""
WEIGHTS = {"severity": 0.5, "reports": 0.3, "age": 0.2}


def priority_score(severity, n_reports, age_days, weights=WEIGHTS):
    parts = {
        "severity": weights["severity"] * severity / 5,
        "reports": weights["reports"] * min(n_reports, 10) / 10,
        "age": weights["age"] * min(age_days, 14) / 14,
    }
    return round(100 * sum(parts.values()), 1), {k: round(100 * v, 1) for k, v in parts.items()}


def explain(issue, score, parts):
    kw = ", ".join(issue["keywords"]) or "n/a"
    sev_why = "; ".join(issue["severity_reasons"])
    return (f"Priority {score}/100 = severity {parts['severity']} + reports {parts['reports']} + age {parts['age']}. "
            f"Severity {issue['severity']}/5 ({sev_why}). {issue['n_reports']} report(s), open {issue['age_days']} day(s). "
            f"Category '{issue['category']}' decided by words: {kw}.")
