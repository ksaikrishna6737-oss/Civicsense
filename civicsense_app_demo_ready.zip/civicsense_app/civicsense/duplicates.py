"""Step 3: is this complaint a re-report of an issue we already know about?

A new complaint joins an existing issue only if ALL of these hold:
  - same category, within `radius_m` metres of the issue's spot, reported within `window_days`
  - (optional) the wording is similar enough: similarity >= threshold. threshold=0 switches this check off.

Similarity backends (same interface, pick with backend=...):
  tfidf_word  cosine of word TF-IDF vectors          -- sees only shared WORDS
  tfidf_char  cosine of character 3-5-gram TF-IDF     -- tolerates misspellings, still not meaning
  embedding   sentence embeddings (all-MiniLM-L6-v2)  -- compares MEANING; needs `pip install sentence-transformers`
              and internet to download the model once (works in Google Colab)
Measured results for each backend come from benchmark_v2.py.
"""
from math import radians, sin, cos, asin, sqrt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def distance_m(lat1, lon1, lat2, lon2):
    """Straight-line distance on Earth in metres (haversine formula)."""
    dlat, dlon = radians(lat2 - lat1), radians(lon2 - lon1)
    a = sin(dlat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2) ** 2
    return 2 * 6371000 * asin(sqrt(a))


class DuplicateDetector:
    def __init__(self, threshold=0.0, window_days=7, radius_m=100, backend="tfidf_word"):
        self.threshold, self.window_days, self.radius_m, self.backend = threshold, window_days, radius_m, backend
        self._cache = {}

    def fit(self, texts):
        if self.backend == "tfidf_word":
            self.vec = TfidfVectorizer(stop_words="english", sublinear_tf=True).fit(texts)
        elif self.backend == "tfidf_char":
            self.vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), sublinear_tf=True).fit(texts)
        elif self.backend == "embedding":
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer("all-MiniLM-L6-v2")
        else:
            raise ValueError("unknown backend: " + self.backend)
        return self

    def _vec(self, text):
        if text not in self._cache:
            if self.backend == "embedding":
                self._cache[text] = self.model.encode([text], normalize_embeddings=True)[0]
            else:
                self._cache[text] = self.vec.transform([text])
        return self._cache[text]

    def _similarity(self, text, other_texts):
        v = self._vec(text)
        if self.backend == "embedding":
            return float(max(self._vec(o) @ v for o in other_texts))
        return max(float(cosine_similarity(v, self._vec(o))[0, 0]) for o in other_texts)

    def match(self, text, lat, lon, category, created_at, issues):
        """Return (issue_id, similarity) of the best matching open issue, or None."""
        best = None
        for issue in issues:
            if issue["category"] != category:
                continue
            if distance_m(lat, lon, issue["lat"], issue["lon"]) > self.radius_m:
                continue
            if (created_at - issue["last_reported"]).days > self.window_days:
                continue
            sim = self._similarity(text, issue["texts"]) if self.threshold > 0 else 1.0
            if sim >= self.threshold and (best is None or sim > best[1]):
                best = (issue["id"], float(sim))
        return best
