"""Find this computer's address on the local Wi-Fi, so phones can open the app."""
import socket


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))     # no data is sent; this only picks the right network adapter
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()
