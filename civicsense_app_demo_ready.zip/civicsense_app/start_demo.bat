@echo off
cd /d "%~dp0"
echo Checking requirements (first time can take a few minutes)...
python -m pip install -q -r requirements.txt
python start_demo.py
pause
