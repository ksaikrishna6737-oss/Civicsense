# CivicSense app: demo-day guide

## Start it from your laptop
1. Install Python 3.10+ (python.org, tick "Add Python to PATH"). Unzip this folder.
2. Double-click `start_demo.bat`. (First time it installs packages: a few minutes.) If the .bat does not work, open a terminal here and run: `pip install -r requirements.txt` then `python start_demo.py`.
3. The window prints two addresses. Open the first (localhost) on the laptop. Windows may ask about the firewall: allow "Private networks".
4. Officer dashboard password: `admin123` (change it with the environment variable CIVICSENSE_ADMIN). Admin tab > "Load 150 demo complaints".

## Open it on phones
- Phones must be on the SAME Wi-Fi as the laptop. College Wi-Fi often blocks this: if the phone cannot open the address, turn on your phone's hotspot and connect the laptop to it.
- Officer dashboard > Admin tab shows a QR code. Scan it with the phone camera.

## Put it on the phone's home screen
- Android (Chrome): menu (three dots) > "Add to Home screen" or "Install app".
- iPhone (Safari): Share button > "Add to Home Screen".
This adds an icon that opens CivicSense like an app. It is not a true Android widget (that needs a native app). Over plain http:// the icon may open with the browser's address bar; full-screen needs https (Streamlit Cloud or a tunnel).

## Show-off script (3 minutes)
1. Load demo data, show the ranked list and click one issue to read the reason.
2. Audience scans the QR, reports a problem on their phones.
3. Click "Refresh data": their reports appear and merge when similar and nearby.
4. Mark one issue resolved; look it up with its ticket number on "Track my report".
5. Download the CSVs (Admin tab) for Power BI.

## Notes
- Data is saved on this laptop in civicsense.db (Admin tab > Delete all data to reset). Photos go in the uploads/ folder and are not analysed.
- "Use my location" button: `pip install streamlit-geolocation`, and it needs https. Otherwise pick the area and fine-tune latitude/longitude.
- Run the checks: `python test_app.py`.
- The category model is trained on synthetic data. New reports appear on other screens after a refresh (no live push).
